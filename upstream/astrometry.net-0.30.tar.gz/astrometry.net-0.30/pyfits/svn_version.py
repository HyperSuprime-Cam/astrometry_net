__svn_version__ = '455'

__full_svn_info__ = '''
Path: .
URL: https://www.stsci.edu/svn/ssb/pyfits/trunk
Repository Root: https://www.stsci.edu/svn/ssb/pyfits
Repository UUID: 7af83f8a-4afa-0310-a21a-a3b59b6a7902
Revision: 455
Node Kind: directory
Schedule: normal
Last Changed Author: jtaylor2
Last Changed Rev: 442
Last Changed Date: 2009-04-22 08:43:13 -0400 (Wed, 22 Apr 2009)
'''

import datetime # setupdate
setupdate = datetime.datetime(2009, 4, 22, 10, 15, 14, 479674) # setupdate
