]
ngc2000accurate = [
